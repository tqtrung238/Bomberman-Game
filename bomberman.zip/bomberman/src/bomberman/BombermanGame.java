package bomberman;

import bomberman.gui.Frame;

public class BombermanGame {
	
	public static void main(String[] args) {
		new Frame();
	}
}
